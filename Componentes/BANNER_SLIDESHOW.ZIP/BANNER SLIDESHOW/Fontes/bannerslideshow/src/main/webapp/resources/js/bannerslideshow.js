var easysSiderObj = {
	// attributes
	instanceId: null,
	mode: null,
	typeOfFiles: null,
	divContainerElement: null,
	documentsAttrs: {},
	
	// attributes to configure the images
	showlastimage: 'all',
	maxImageCreateDate: null,
	
	// standards methods
	init: function(instanceId) {
		this.csClearInterface();
		this.csLoadRecords();
		
		var thisSlider = this;
		$("#btnsave", this.csGetDivContainer()).on('click', function(event) {
			thisSlider.csSave();
		});
		
		$("embed", this.csGetDivContainer()).each(function(key, value) {
			var idEmbed = $(value).attr('id');
			
			if (!window.hasOwnProperty('embedIds')) {
				window['embedIds'] = new Array();
			}
			window.embedIds.push(idEmbed);
		});
		
		var hiperlink = $("input[name=linkimage]", this.csGetDivContainer());
		var sameOrOther = (hiperlink.length !== 0 && hiperlink.val() === 'other') ? '_blank' : '_self';
		$("a", this.csGetDivContainer()).attr('target', sameOrOther);
		
		this.showlastimage = $("#showlastimage", this.csGetDivContainer()).val();
	},
	
	bindings: {
		local: {
			folder: ['click_csChooseFolder']
		},
		global: {
			time: ['click_csChooseFolder']
		}
	},
	
	// custom methods
	
	/**
	 * Get Easy Slider's div container to limit scope of instance
	 */
	csGetDivContainer: function() {
		if (this.divContainerElement === null) {
			this.divContainerElement = $("#bannerslideshow_" + this.instanceId);
		}
		return this.divContainerElement;
	},
	
	/**
	 * Get file's attributes
	 */
	csGetElementAttrs: function(documentId) {
		var bannerslideshow = this;
		
		if (!this.documentsAttrs.hasOwnProperty(documentId)) {
			$.ajax({
				async: false,						
				success: function(item) {
					bannerslideshow.documentsAttrs[documentId] = item;
				},			
				type: 'GET',
				url: WCMAPI.getServerURL() + "/ecm/api/rest/ecm/documentView/content/" + documentId + "/navigation?_="
			});
		}
		
		return this.documentsAttrs[documentId];
	},
	
	/**
	 * Get file's public URL
	 */
	csGetElementURL: function(documentId) {
		var retorno = null;
		var elementAttrs = this.csGetElementAttrs(documentId);
		
		if (elementAttrs.hasOwnProperty('phisicalFile')) {
			retorno = elementAttrs.phisicalFile;
		}
		
		return retorno;
	},
	
	/**
	 * Create HTML to image element
	 */
	csAddImage: function(documentId, parentElement) {
		var attrs = this.csGetElementAttrs(documentId);
		var url = [
		           WCMAPI.getServerURL(),
		           "api/public/ecm/document/documentfile",
		           attrs.documentId,
		           attrs.version
        ].join('/');
		
		var createDate = attrs.createDate.split('-').join('');
		var showImage = $("#showlastimage", this.csGetDivContainer()).val();
		
		parentElement.addClass('cs-image-container');
		parentElement.addClass(createDate);
		
		// exibe a �ltima imagem cadastrada
		if (showImage === 'last') {
			if (!this.hasOwnProperty('maxImageCreateDate') || 
				 this.maxImageCreateDate < createDate) {
				this.maxImageCreateDate = createDate;
			}
			
			if (!this.hasOwnProperty('parentsElements')) {
				this.parentsElements = new Array();
			}
			this.parentsElements.push({
				'attrs': attrs,
				'parentElement': parentElement
			});
		}
		
		
		/*var $img = $("<img>", {
			'src': url,
			'width': '100%'
		});*/
		
		(new Image()).src = $.trim(url);
		
		var $img = $("<img>", {
			'url': '',
			'data-src': url,
			'width': '100%'
		});
		
		if (attrs.additionalComments.indexOf('http://') !== -1 || 
			attrs.additionalComments.indexOf('https://') !== -1) {
			var $ahref = $("<a>", {
				'href': attrs.additionalComments,
				'target': '_blank',
				'title': attrs.documentDescription
			});
			$ahref.append($img);
			return parentElement.append($ahref);
		}
		else {
			return parentElement.append($img);
		}
	},
	
	/**
	 * Create HTML to paragraph element
	 */
	csAddText: function(documentId, parentElement) {
		var url = this.csGetElementURL(documentId);
		var content = '';
		
		$.get(url, function(data) {
			content = data;
		}, 'html')
		.done(function() {
			var text = $('<p>', {
				'html': content
			});
			parentElement.append(text);
		});
		return parentElement;
	},
	
	/**
	 * Create HTML to video (iframe) element
	 */
	csAddVideo: function(documentId, parentElement) {
		var url = this.csGetElementURL(documentId);
		var instanceId = this.instanceId;
		var conc = '?';
		var isYouTube = (url.indexOf('youtube') !== -1);
		var $object, $param1, $param2, $param3, $embed;
		
		if (isYouTube) {	
			this.csAddYouTubeAPI();
			
			var urlParts = url.split('/');
			var lastPart = urlParts[urlParts.length - 1];
			var playerId = 'player' + documentId;
			
			url = ['http://www.youtube.com/v', lastPart].join('/');
			
			if (url.indexOf('?') !== -1) {
				conc = '&';
			}
			
			url = [url, 'enablejsapi=1'].join(conc);
			
			$object = $("<object>", {
				'width': '640',
				'height': '360'
			});
			
			$param1 = $("<param>", {
				'name': 'movie',
				'value': url
			});
			$param2 = $("<param>", {
				'name': 'allowFullScreen',
				'value': 'true'
			});
			$param3 = $("<param>", {
				'name': 'allowScriptAccess',
				'value': 'always'
			});
			$embed = $("<embed>", {
				'src': url,
				'type': 'application/x-shockwave-flash',
				'allowfullscreen': 'true',
				'allowScriptAccess': 'always',
				'width': '640',
				'height': '360',
				'id': playerId
			});
			
			$object.append($param1).append($param2).append($param3).append($embed);
			
			return parentElement.append($object);
		}
		else {
			this.csAddVimeoAPI();
			
			var urlParts = url.split('/');
			var lastPart = urlParts[urlParts.length - 1];
			var playerId = 'vimeoPlayer' + documentId;
			
			url = ['http://player.vimeo.com/video', lastPart].join('/');
			
			if (url.indexOf('?') !== -1) {
				conc = '&';
			}
			url = [url, 'api=1'].join(conc);
			
			var iFrame = $("<iframe>", {
				'height': '315',
				'src': url,
				'width': '560',
				'allowfullscreen': 'true',
				'allowScriptAccess': 'always',
				'id': playerId
			});
			
			return parentElement.append(iFrame);
		}
	},
	
	/**
	 * Load YouTube API
	 */
	csAddYouTubeAPI: function() {		
		if (this.hasYouTubeScript === null) {
			this.hasYouTubeScript = $("script[src='https://www.youtube.com/player_api']").length;
		}
		
		if (this.hasYouTubeScript !== 0) {
			var $body = $("html > body");
			var $script = $("<script>", {
				'src': 'https://www.youtube.com/player_api'
			});
			$body.append($script);
		}
	},
	
	/**
	 * Load Vimeo API
	 */
	csAddVimeoAPI: function() {		
		if (this.hasVimeoScript === null) {
			this.hasVimeoScript = $("script[src='http://a.vimeocdn.com/js/froogaloop2.min.js']").length;
		}
		
		if (this.hasVimeoScript !== 0) {
			var $body = $("html > body");
			var $script = $("<script>", {
				'src': 'http://a.vimeocdn.com/js/froogaloop2.min.js'
			});
			$body.append($script);
		}
	},
	
	csClearInterface: function() {
		this.csRemoveItem("wcm_controles_widgets");
		this.csRemoveItem("wcm_title_widget");
	},
	
	/**
	 * Choose Fluig folder
	 */
	csChooseFolder: function(el){
		var $dom = this.csGetDivContainer();
		
		this.csEcmThings(function(pastaDestino, nome) {			
			if (pastaDestino && nome) {
				el.value = nome;
				$("#folderNumber", $dom).val(pastaDestino);				
				return;
			}			
		});
	},
	
	/**
	 * Open dialog to choose Fluig folder
	 */
	csEcmThings: function(callback) {
		var zoomECM = function() {
			ECM.findDocument = new Object();

			ECM.findDocument.panel = WCMC.panel({
				url: "/ecm_finddocument/finddocument.ftl",
				width: 750,
				height: 600,
				maximized: true,
				title: "${i18n.getTranslation('bannerslideshow.selectfolderwindowtitle')}", 
				callBack: function(){
					ECM.findDocument.getDocuments(0,1,false,3);
				},
				customButtons: new Array("${i18n.getTranslation('bannerslideshow.selectfolder')}") 
			});

			ECM.findDocument.panel.bind("panel-button-0", function() {
				var pastaDestino, nome;

				if (ECM.findDocument.dataTable.selectedRows.length > 1) {
					WCMC.messageWarn("${i18n.getTranslation('bannerslideshow.selectonlyonefolder')}" + ".");
					return;
				}

				pastaDestino = parseInt(ECM.findDocument.dataTable.selectedRows[0]);

				if (ECM.findDocument.dataTable.selectedRows.length === 0 || pastaDestino === undefined || pastaDestino === NaN || pastaDestino === 0) {
					WCMC.messageWarn("${i18n.getTranslation('bannerslideshow.selectfolder')}" + ".");
					return;
				}

				nome = ECM.findDocument.dataTable.getData(pastaDestino).documentDescription;

				ECM.findDocument.load.hide();
				ECM.findDocument.panel.close();
				callback(pastaDestino, nome);
			});

			ECM.findDocument.panel.bind("panel-button-close", function() {
				var pastaDestino = false, nome = false;
				callback(pastaDestino, nome);
			});
		};
		zoomECM.apply();
	},
	
	/**
	 * Load the records and create the cycle structure
	 */
	csLoadRecords: function() {	
		var $this = this;
		var $dom = $this.csGetDivContainer();
		var url = null;			
		var typeOfFiles = this.typeOfFiles;
		
		var hasFolderAndIsView = ($("#folderNumber", $dom).length !== 0 && $('#isViewForm', $dom).length !== 0);
		var hasFolderValue = ($("#folderNumber", $dom).attr('value').length !== 0);
		
		if (!hasFolderAndIsView || !hasFolderValue) {
			return;
		}
		
		// url = WCMAPI.getServerURL() + "/api/public/social/community/folder/" + $('#folderNumber', $dom).attr('value') + '?limit=200&offset=0';
		
		url = WCMAPI.getServerURL() + "/ecm/api/rest/ecm/navigation/content/" + $('#folderNumber', $dom).attr('value') + "?rows=5000";
		
		$.ajax({
			async: false,	
			url: url,
			type: 'GET',
		})
		.done(function(data) {		
			data = data.invdata;
			
			var types = {
				2: 'csAddImage',
				3: 'csAddVideo',
				8: 'csAddText'
			};
			
			var $parentDiv = $('.cycle-slideshow', $dom);
			
			$.each(data, function(key, value) {	
				// verifica se o tipo de arquivo � suportado pelo script
				if (!types.hasOwnProperty(value.documentType)) {
					return true;
				}
				
				// exibe somente os tipos de arquivos que o usu�rios selecionou
				if (typeOfFiles !== 'all') {
					if (typeOfFiles !== value.documentType) {
						return true;
					}
				}
				
				// verifica a data de validade do arquivo
				if (value.expires == true && value.expired < 0) {
					return true;
				}
				
				var methodName = types[value.documentType];
				var $div = $('<div>');
				
				// videos class
				if (value.documentType == 3) {
					$div.addClass('video-container');
				}
				
				$div = $this[methodName](value.documentId, $div);
				
				if ($div !== null) {
					$parentDiv.append($div);
				}				
			});
		})
		.fail(function() {
			// code
		})
		.always(function() {
			// code
		});
				
		/*
		 * In�cio da listagem da �ltima imagem criada
		 * se esta op��o foi marcada pelo usu�rio
		 */
		if (this.hasOwnProperty('maxImageCreateDate')) {
			var e = $this.parentsElements,
				safeDiv = null;
			
			$.each(e, function(key, elm) {
				var createDate = elm.attrs.createDate.split('-').join('');
				
				if ($this.maxImageCreateDate < createDate) {
					$this.maxImageCreateDate = createDate;
				}
			});
			
			// exclui todas as imagens que possuem datas de cria��o inferiores a $this.maxImageCreateDate
			$(".cycle-slideshow > div.cs-image-container:not(." + $this.maxImageCreateDate + ")", $dom).remove();
			
			// quantidade de elementos que sobraram
			var qtdeElements = $(".cycle-slideshow > div.cs-image-container." + $this.maxImageCreateDate, $dom);
			if (qtdeElements.length > 1) {
				var count = 0;
				qtdeElements.each(function(key, value) {
					if (count < qtdeElements.length - 1) {
						$(value).remove();
					}
					count++;
				});
			}
			
		}
		
		/*
		 * In�cio da manipula��o da altura do container do slideshow
		 */
		if (!this.hasOwnProperty('maxDivPaddingBottom')) {
			this['maxDivPaddingBottom'] = parseFloat(0);
		}
		
		$(".cycle-slideshow > div > *", $dom).on('load', function() {			
			$(".cycle-slideshow > div", $dom).each(function(key, value) {
				var $element = $("> *", $(value));
				var width = $element.css('width');
				var height = $element.css('height');
				
				width = parseInt( width );
				height = parseInt( height );
				
				var porcent = (height*100)/width;
				
				porcent = parseFloat( porcent );
				
				if (porcent > $this.maxDivPaddingBottom) {
					$this.maxDivPaddingBottom = porcent;
				}
			});
			
			$(".cycle-slideshow > div", $dom).css('padding-bottom', $this.maxDivPaddingBottom + '%');
		});
	},
	
	csRemoveItem: function(classe) {		
		var divPai = $("#wcm_widget_" + this.instanceId);
		
		$('div', divPai).each(function(key, value) {
			value = $(value);
			if (value.is('[class]') && value.attr('name') == classe) {
				value.css('display', 'none');
			}
		});
	},
	
	/**
	 * Save the widget configuration
	 */
	csSave: function(element, event) {			
		var result = WCMSpaceAPI.PageService.UPDATEPREFERENCES({ async:false }, this.instanceId, {
			folder: $("#folder", this.csGetDivContainer()).val(),
			folderNumber: $("#folderNumber", this.csGetDivContainer()).val(),
			type: $("#type", this.csGetDivContainer()).val(),
			fx: $("#fx", this.csGetDivContainer()).val(),
			random: $("#random", this.csGetDivContainer()).val(),
			loop: $("#loop", this.csGetDivContainer()).val(),
			mark: $("#mark", this.csGetDivContainer()).val(),
			time: $("#time", this.csGetDivContainer()).val(),
			transition: $("#transition", this.csGetDivContainer()).val(),
			linkimage: $("#linkimage", this.csGetDivContainer()).val(),
			showlastimage: $("#showlastimage", this.csGetDivContainer()).val(),
			marklocation: $("#marklocation", this.csGetDivContainer()).val(),
			marktype: $("#marktype", this.csGetDivContainer()).val(),			
			title: $("#title", this.csGetDivContainer()).val(),
			titleFontColor: $("#titleFontColor", this.csGetDivContainer()).val(),
			titleBackgroundColor: $("#titleBackgroundColor", this.csGetDivContainer()).val()
		});
		
	    if (result) {
	        WCMC.messageInfo(result.message);
	    } 
	    else {
	    	WCMC.messageError("${i18n.getTranslation('bannerslideshow.save.error')}");
	    }
	}
}; 

var bannerslideshow = SuperWidget.extend(easysSiderObj);
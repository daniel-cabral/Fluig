$(document).ready(function() {
	var $titleSlideShow = $('.title-slideshow');
	if ($titleSlideShow.length > 0) {
		$titleSlideShow.css('background-color', $titleSlideShow.data("titlebackgroundcolor"));
		$titleSlideShow.css('color', $titleSlideShow.data("titlefontcolor"));
	}
});

// vimeo player
$(window).ready(function() {		
	/*
	$("[id^=vimeoPlayer]").each(function(key, player) {
		vPlayer = $f(player);
	    $f(player).addEvent('ready', function() {
	        console.log('ready');
	        
	        player.addEvent('pause', onPause);
	        player.addEvent('finish', onFinish);
	        player.addEvent('playProgress', onPlayProgress);
	    });
	});
	*/
	
	/**
	 * Utility function for adding an event. Handles the inconsistencies
	 * between the W3C method for adding events (addEventListener) and
	 * IE's (attachEvent).
	 */
	function addEvent(element, eventName, callback) {
	    if (element.addEventListener) {
	        element.addEventListener(eventName, callback, false);
	    }
	    else {
	        element.attachEvent('on' + eventName, callback);
	    }
	}
	
	function onPause(id) {
		console.log('paused');
	}

	function onFinish(id) {
		console.log('finished');
	}

	function onPlayProgress(data, id) {
		console.log(data.seconds + 's played');
	}
	
	$(".cycle-slideshow img[data-src]").each(function(k, v) {
		$(this).attr('src', $(this).attr('data-src'));
	});
});


// youtube player
function onYouTubePlayerReady(playerId) {	
	if (window.hasOwnProperty('embedIds')) {
		$.each(window.embedIds, function(key, idEmbed) {
			ytplayer = document.getElementById(idEmbed);
			ytplayer.addEventListener("onStateChange", "onytplayerStateChange");
			
			if (!window.hasOwnProperty('parentEmbedIds')) {
				window['parentEmbedIds'] = {};
			}
			window.parentEmbedIds[idEmbed] = $("#"+embedIds).parent().parent().parent().attr('id');
		});
	}
}

function onytplayerStateChange(newState) {
	for (var p in window.embedIds) {
		var idEmbed = window.embedIds[p];
		var player = document.getElementById(idEmbed);
		var playerState = player.getPlayerState();
		
		if (newState == 1) {
			$("#" + window.parentEmbedIds[idEmbed]).cycle('pause');
			break;
		}
		else if (newState == 0 || newState == 2) {
			$("#" + window.parentEmbedIds[idEmbed]).cycle('resume');
			break;
		}
	}
}
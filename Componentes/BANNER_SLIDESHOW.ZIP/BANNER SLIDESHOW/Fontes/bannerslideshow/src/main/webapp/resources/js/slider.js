(function(e){(function(e){"use strict";function n(e){return(e||"").toLowerCase()}
var t="2.1.5";e.fn.cycle=function(t){var r;if(this.length===0&&!e.isReady){r={s:this.selector,c:this.context};e.fn.cycle.log("requeuing slideshow (dom not ready)");e(function(){e(r.s,r.c).cycle(t)});return this}
return this.each(function(){var r,i,s,o;var u=e(this);var a=e.fn.cycle.log;if(u.data("cycle.opts"))
return;if(u.data("cycle-log")===false||t&&t.log===false||i&&i.log===false){a=e.noop}
a("--c2 init--");r=u.data();for(var f in r){if(r.hasOwnProperty(f)&&/^cycle[A-Z]+/.test(f)){o=r[f];s=f.match(/^cycle(.*)/)[1].replace(/^[A-Z]/,n);a(s+":",o,"("+typeof o+")");r[s]=o}}
i=e.extend({},e.fn.cycle.defaults,r,t||{});i.timeoutId=0;i.paused=i.paused||false;i.container=u;i._maxZ=i.maxZ;i.API=e.extend({_container:u},e.fn.cycle.API);i.API.log=a;i.API.trigger=function(e,t){i.container.trigger(e,t);return i.API};u.data("cycle.opts",i);u.data("cycle.API",i.API);i.API.trigger("cycle-bootstrap",[i,i.API]);i.API.addInitialSlides();i.API.preInitSlideshow();if(i.slides.length)
i.API.initSlideshow()})};e.fn.cycle.API={opts:function(){return this._container.data("cycle.opts")},addInitialSlides:function(){var t=this.opts();var n=t.slides;t.slideCount=0;t.slides=e();n=n.jquery?n:t.container.find(n);if(t.random){n.sort(function(){return Math.random()-.5})}
t.API.add(n)},preInitSlideshow:function(){var t=this.opts();t.API.trigger("cycle-pre-initialize",[t]);var n=e.fn.cycle.transitions[t.fx];if(n&&e.isFunction(n.preInit))
n.preInit(t);t._preInitialized=true},postInitSlideshow:function(){var t=this.opts();t.API.trigger("cycle-post-initialize",[t]);var n=e.fn.cycle.transitions[t.fx];if(n&&e.isFunction(n.postInit))
n.postInit(t)},initSlideshow:function(){var t=this.opts();var n=t.container;var r;t.API.calcFirstSlide();if(t.container.css("position")=="static")
t.container.css("position","relative");e(t.slides[t.currSlide]).css({opacity:1,display:"block",visibility:"visible"});t.API.stackSlides(t.slides[t.currSlide],t.slides[t.nextSlide],!t.reverse);if(t.pauseOnHover){if(t.pauseOnHover!==true)
n=e(t.pauseOnHover);n.hover(function(){t.API.pause(true)},function(){t.API.resume(true)})}
if(t.timeout){r=t.API.getSlideOpts(t.currSlide);t.API.queueTransition(r,r.timeout+t.delay)}
t._initialized=true;t.API.updateView(true);t.API.trigger("cycle-initialized",[t]);t.API.postInitSlideshow()},pause:function(t){var n=this.opts(),r=n.API.getSlideOpts(),i=n.hoverPaused||n.paused;if(t)
n.hoverPaused=true;else
n.paused=true;if(!i){n.container.addClass("cycle-paused");n.API.trigger("cycle-paused",[n]).log("cycle-paused");if(r.timeout){clearTimeout(n.timeoutId);n.timeoutId=0;n._remainingTimeout-=e.now()-n._lastQueue;if(n._remainingTimeout<0||isNaN(n._remainingTimeout))
n._remainingTimeout=undefined}}},resume:function(e){var t=this.opts(),n=!t.hoverPaused&&!t.paused,r;if(e)
t.hoverPaused=false;else
t.paused=false;if(!n){t.container.removeClass("cycle-paused");if(t.slides.filter(":animated").length===0)
t.API.queueTransition(t.API.getSlideOpts(),t._remainingTimeout);t.API.trigger("cycle-resumed",[t,t._remainingTimeout]).log("cycle-resumed")}},add:function(t,n){var r=this.opts();var i=r.slideCount;var s=false;var o;if(e.type(t)=="string")
t=e.trim(t);e(t).each(function(t){var i;var s=e(this);if(n)
r.container.prepend(s);else
r.container.append(s);r.slideCount++;i=r.API.buildSlideOpts(s);if(n)
r.slides=e(s).add(r.slides);else
r.slides=r.slides.add(s);r.API.initSlide(i,s,--r._maxZ);s.data("cycle.opts",i);r.API.trigger("cycle-slide-added",[r,i,s])});r.API.updateView(true);s=r._preInitialized&&i<2&&r.slideCount>=1;if(s){if(!r._initialized)
r.API.initSlideshow();else if(r.timeout){o=r.slides.length;r.nextSlide=r.reverse?o-1:1;if(!r.timeoutId){r.API.queueTransition(r)}}}},calcFirstSlide:function(){var e=this.opts();var t;t=parseInt(e.startingSlide||0,10);if(t>=e.slides.length||t<0)
t=0;e.currSlide=t;if(e.reverse){e.nextSlide=t-1;if(e.nextSlide<0)
e.nextSlide=e.slides.length-1}else{e.nextSlide=t+1;if(e.nextSlide==e.slides.length)
e.nextSlide=0}},calcNextSlide:function(){var e=this.opts();var t;if(e.reverse){t=e.nextSlide-1<0;e.nextSlide=t?e.slideCount-1:e.nextSlide-1;e.currSlide=t?0:e.nextSlide+1}else{t=e.nextSlide+1==e.slides.length;e.nextSlide=t?0:e.nextSlide+1;e.currSlide=t?e.slides.length-1:e.nextSlide-1}},calcTx:function(t,n){var r=t;var i;if(r._tempFx)
i=e.fn.cycle.transitions[r._tempFx];else if(n&&r.manualFx)
i=e.fn.cycle.transitions[r.manualFx];if(!i)
i=e.fn.cycle.transitions[r.fx];r._tempFx=null;this.opts()._tempFx=null;if(!i){i=e.fn.cycle.transitions.fade;r.API.log('Transition "'+r.fx+'" not found.  Using fade.')}
return i},prepareTx:function(e,t){var n=this.opts();var r,i,s,o,u;if(n.slideCount<2){n.timeoutId=0;return}
if(e&&(!n.busy||n.manualTrump)){n.API.stopTransition();n.busy=false;clearTimeout(n.timeoutId);n.timeoutId=0}
if(n.busy)
return;if(n.timeoutId===0&&!e)
return;i=n.slides[n.currSlide];s=n.slides[n.nextSlide];o=n.API.getSlideOpts(n.nextSlide);u=n.API.calcTx(o,e);n._tx=u;if(e&&o.manualSpeed!==undefined)
o.speed=o.manualSpeed;if(n.nextSlide!=n.currSlide&&(e||!n.paused&&!n.hoverPaused&&n.timeout)){n.API.trigger("cycle-before",[o,i,s,t]);if(u.before)
u.before(o,i,s,t);r=function(){n.busy=false;if(!n.container.data("cycle.opts"))
return;if(u.after)
u.after(o,i,s,t);n.API.trigger("cycle-after",[o,i,s,t]);n.API.queueTransition(o);n.API.updateView(true)};n.busy=true;if(u.transition)
u.transition(o,i,s,t,r);else
n.API.doTransition(o,i,s,t,r);n.API.calcNextSlide();n.API.updateView()}else{n.API.queueTransition(o)}},doTransition:function(t,n,r,i,s){var o=t;var u=e(n),a=e(r);var f=function(){a.animate(o.animIn||{opacity:1},o.speed,o.easeIn||o.easing,s)};a.css(o.cssBefore||{});u.animate(o.animOut||{},o.speed,o.easeOut||o.easing,function(){u.css(o.cssAfter||{});if(!o.sync){f()}});if(o.sync){f()}},queueTransition:function(t,n){var r=this.opts();var i=n!==undefined?n:t.timeout;if(r.nextSlide===0&&--r.loop===0){r.API.log("terminating; loop=0");r.timeout=0;if(i){setTimeout(function(){r.API.trigger("cycle-finished",[r])},i)}else{r.API.trigger("cycle-finished",[r])}
r.nextSlide=r.currSlide;return}
if(r.continueAuto!==undefined){if(r.continueAuto===false||e.isFunction(r.continueAuto)&&r.continueAuto()===false){r.API.log("terminating automatic transitions");r.timeout=0;if(r.timeoutId)
clearTimeout(r.timeoutId);return}}
if(i){r._lastQueue=e.now();if(n===undefined)
r._remainingTimeout=t.timeout;if(!r.paused&&!r.hoverPaused){r.timeoutId=setTimeout(function(){r.API.prepareTx(false,!r.reverse)},i)}}},stopTransition:function(){var e=this.opts();if(e.slides.filter(":animated").length){e.slides.stop(false,true);e.API.trigger("cycle-transition-stopped",[e])}
if(e._tx&&e._tx.stopTransition)
e._tx.stopTransition(e)},advanceSlide:function(e){var t=this.opts();clearTimeout(t.timeoutId);t.timeoutId=0;t.nextSlide=t.currSlide+e;if(t.nextSlide<0)
t.nextSlide=t.slides.length-1;else if(t.nextSlide>=t.slides.length)
t.nextSlide=0;t.API.prepareTx(true,e>=0);return false},buildSlideOpts:function(t){var r=this.opts();var i,s;var o=t.data()||{};for(var u in o){if(o.hasOwnProperty(u)&&/^cycle[A-Z]+/.test(u)){i=o[u];s=u.match(/^cycle(.*)/)[1].replace(/^[A-Z]/,n);r.API.log("["+(r.slideCount-1)+"]",s+":",i,"("+typeof i+")");o[s]=i}}
o=e.extend({},e.fn.cycle.defaults,r,o);o.slideNum=r.slideCount;try{delete o.API;delete o.slideCount;delete o.currSlide;delete o.nextSlide;delete o.slides}catch(a){}
return o},getSlideOpts:function(t){var n=this.opts();if(t===undefined)
t=n.currSlide;var r=n.slides[t];var i=e(r).data("cycle.opts");return e.extend({},n,i)},initSlide:function(t,n,r){var i=this.opts();n.css(t.slideCss||{});if(r>0)
n.css("zIndex",r);if(isNaN(t.speed))
t.speed=e.fx.speeds[t.speed]||e.fx.speeds._default;if(!t.sync)
t.speed=t.speed/2;n.addClass(i.slideClass)},updateView:function(e,t,n){var r=this.opts();if(!r._initialized)
return;var i=r.API.getSlideOpts();var s=r.slides[r.currSlide];if(!e&&t!==true){r.API.trigger("cycle-update-view-before",[r,i,s]);if(r.updateView<0)
return}
if(r.slideActiveClass){r.slides.removeClass(r.slideActiveClass).eq(r.currSlide).addClass(r.slideActiveClass)}
if(e&&r.hideNonActive)
r.slides.filter(":not(."+r.slideActiveClass+")").css("visibility","hidden");if(r.updateView===0){setTimeout(function(){r.API.trigger("cycle-update-view",[r,i,s,e])},i.speed/(r.sync?2:1))}
if(r.updateView!==0)
r.API.trigger("cycle-update-view",[r,i,s,e]);if(e)
r.API.trigger("cycle-update-view-after",[r,i,s])},getComponent:function(t){var n=this.opts();var r=n[t];if(typeof r==="string"){return/^\s*[\>|\+|~]/.test(r)?n.container.find(r):e(r)}
if(r.jquery)
return r;return e(r)},stackSlides:function(t,n,r){var i=this.opts();if(!t){t=i.slides[i.currSlide];n=i.slides[i.nextSlide];r=!i.reverse}
e(t).css("zIndex",i.maxZ);var s;var o=i.maxZ-2;var u=i.slideCount;if(r){for(s=i.currSlide+1;s<u;s++)
e(i.slides[s]).css("zIndex",o--);for(s=0;s<i.currSlide;s++)
e(i.slides[s]).css("zIndex",o--)}else{for(s=i.currSlide-1;s>=0;s--)
e(i.slides[s]).css("zIndex",o--);for(s=u-1;s>i.currSlide;s--)
e(i.slides[s]).css("zIndex",o--)}
e(n).css("zIndex",i.maxZ-1)},getSlideIndex:function(e){return this.opts().slides.index(e)}};e.fn.cycle.log=function(){if(window.console&&console.log)
console.log("[cycle2] "+Array.prototype.join.call(arguments," "))};e.fn.cycle.version=function(){return"Cycle2: "+t};e.fn.cycle.transitions={custom:{},none:{before:function(e,t,n,r){e.API.stackSlides(n,t,r);e.cssBefore={opacity:1,visibility:"visible",display:"block"}}},fade:{before:function(t,n,r,i){var s=t.API.getSlideOpts(t.nextSlide).slideCss||{};t.API.stackSlides(n,r,i);t.cssBefore=e.extend(s,{opacity:0,visibility:"visible",display:"block"});t.animIn={opacity:1};t.animOut={opacity:0}}},fadeout:{before:function(t,n,r,i){var s=t.API.getSlideOpts(t.nextSlide).slideCss||{};t.API.stackSlides(n,r,i);t.cssBefore=e.extend(s,{opacity:1,visibility:"visible",display:"block"});t.animOut={opacity:0}}},scrollHorz:{before:function(e,t,n,r){e.API.stackSlides(t,n,r);var i=e.container.css("overflow","hidden").width();e.cssBefore={left:r?i:-i,top:0,opacity:1,visibility:"visible",display:"block"};e.cssAfter={zIndex:e._maxZ-2,left:0};e.animIn={left:0};e.animOut={left:r?-i:i}}}};e.fn.cycle.defaults={allowWrap:true,autoSelector:".cycle-slideshow[data-cycle-auto-init!=false]",delay:0,easing:null,fx:"fade",hideNonActive:true,loop:0,manualFx:undefined,manualSpeed:undefined,manualTrump:true,maxZ:100,pauseOnHover:false,reverse:false,slideActiveClass:"cycle-slide-active",slideClass:"cycle-slide",slideCss:{position:"absolute",top:0,left:0},slides:"> img",speed:500,startingSlide:0,sync:true,timeout:4e3,updateView:0};e(document).ready(function(){e(e.fn.cycle.defaults.autoSelector).cycle()})})(e);(function(e){"use strict";function t(t,r){var i,s,o;var u=r.autoHeight;if(u=="container"){s=e(r.slides[r.currSlide]).outerHeight();r.container.height(s)}else if(r._autoHeightRatio){r.container.height(r.container.width()/r._autoHeightRatio)}else if(u==="calc"||e.type(u)=="number"&&u>=0){if(u==="calc")
o=n(t,r);else if(u>=r.slides.length)
o=0;else
o=u;if(o==r._sentinelIndex)
return;r._sentinelIndex=o;if(r._sentinel)
r._sentinel.remove();i=e(r.slides[o].cloneNode(true));i.removeAttr("id name rel").find("[id],[name],[rel]").removeAttr("id name rel");i.css({position:"static",visibility:"hidden",display:"block"}).prependTo(r.container).addClass("cycle-sentinel cycle-slide").removeClass("cycle-slide-active");i.find("*").css("visibility","hidden");r._sentinel=i}}
function n(t,n){var r=0,i=-1;n.slides.each(function(t){var n=e(this).height();if(n>i){i=n;r=t}});return r}
function r(t,n,r,i,s){var o=e(i).outerHeight();n.container.animate({height:o},n.autoHeightSpeed,n.autoHeightEasing)}
function i(n,s){if(s._autoHeightOnResize){e(window).off("resize orientationchange",s._autoHeightOnResize);s._autoHeightOnResize=null}
s.container.off("cycle-slide-added cycle-slide-removed",t);s.container.off("cycle-destroyed",i);s.container.off("cycle-before",r);if(s._sentinel){s._sentinel.remove();s._sentinel=null}}
e.extend(e.fn.cycle.defaults,{autoHeight:0,autoHeightSpeed:250,autoHeightEasing:null});e(document).on("cycle-initialized",function(n,s){function l(){t(n,s)}
var o=s.autoHeight;var u=e.type(o);var a=null;var f;if(u!=="string"&&u!=="number")
return;s.container.on("cycle-slide-added cycle-slide-removed",t);s.container.on("cycle-destroyed",i);if(o=="container"){s.container.on("cycle-before",r)}else if(u==="string"&&/\d+\:\d+/.test(o)){f=o.match(/(\d+)\:(\d+)/);f=f[1]/f[2];s._autoHeightRatio=f}
if(u!=="number"){s._autoHeightOnResize=function(){clearTimeout(a);a=setTimeout(l,50)};e(window).on("resize orientationchange",s._autoHeightOnResize)}
setTimeout(l,30)})})(e);(function(e){"use strict";e.extend(e.fn.cycle.defaults,{caption:"> .cycle-caption",captionTemplate:"{{slideNum}} / {{slideCount}}",overlay:"> .cycle-overlay",overlayTemplate:"<div>{{title}}</div><div>{{desc}}</div>",captionModule:"caption"});e(document).on("cycle-update-view",function(t,n,r,i){if(n.captionModule!=="caption")
return;var s;e.each(["caption","overlay"],function(){var e=this;var t=r[e+"Template"];var s=n.API.getComponent(e);if(s.length&&t){s.html(n.API.tmpl(t,r,n,i));s.show()}else{s.hide()}})});e(document).on("cycle-destroyed",function(t,n){var r;e.each(["caption","overlay"],function(){var e=this,t=n[e+"Template"];if(n[e]&&t){r=n.API.getComponent("caption");r.empty()}})})})(e);(function(e){"use strict";var t=e.fn.cycle;e.fn.cycle=function(n){var r,i,s;var o=e.makeArray(arguments);if(e.type(n)=="number"){return this.cycle("goto",n)}
if(e.type(n)=="string"){return this.each(function(){var u;r=n;s=e(this).data("cycle.opts");if(s===undefined){t.log('slideshow must be initialized before sending commands; "'+r+'" ignored');return}else{r=r=="goto"?"jump":r;i=s.API[r];if(e.isFunction(i)){u=e.makeArray(o);u.shift();return i.apply(s.API,u)}else{t.log("unknown command: ",r)}}})}else{return t.apply(this,arguments)}};e.extend(e.fn.cycle,t);e.extend(t.API,{next:function(){var e=this.opts();if(e.busy&&!e.manualTrump)
return;var t=e.reverse?-1:1;if(e.allowWrap===false&&e.currSlide+t>=e.slideCount)
return;e.API.advanceSlide(t);e.API.trigger("cycle-next",[e]).log("cycle-next")},prev:function(){var e=this.opts();if(e.busy&&!e.manualTrump)
return;var t=e.reverse?1:-1;if(e.allowWrap===false&&e.currSlide+t<0)
return;e.API.advanceSlide(t);e.API.trigger("cycle-prev",[e]).log("cycle-prev")},destroy:function(){this.stop();var t=this.opts();var n=e.isFunction(e._data)?e._data:e.noop;clearTimeout(t.timeoutId);t.timeoutId=0;t.API.stop();t.API.trigger("cycle-destroyed",[t]).log("cycle-destroyed");t.container.removeData();n(t.container[0],"parsedAttrs",false);if(!t.retainStylesOnDestroy){t.container.removeAttr("style");t.slides.removeAttr("style");t.slides.removeClass(t.slideActiveClass)}
t.slides.each(function(){e(this).removeData();n(this,"parsedAttrs",false)})},jump:function(e,t){var n;var r=this.opts();if(r.busy&&!r.manualTrump)
return;var i=parseInt(e,10);if(isNaN(i)||i<0||i>=r.slides.length){r.API.log("goto: invalid slide index: "+i);return}
if(i==r.currSlide){r.API.log("goto: skipping, already on slide",i);return}
r.nextSlide=i;clearTimeout(r.timeoutId);r.timeoutId=0;r.API.log("goto: ",i," (zero-index)");n=r.currSlide<r.nextSlide;r._tempFx=t;r.API.prepareTx(true,n)},stop:function(){var t=this.opts();var n=t.container;clearTimeout(t.timeoutId);t.timeoutId=0;t.API.stopTransition();if(t.pauseOnHover){if(t.pauseOnHover!==true)
n=e(t.pauseOnHover);n.off("mouseenter mouseleave")}
t.API.trigger("cycle-stopped",[t]).log("cycle-stopped")},reinit:function(){var e=this.opts();e.API.destroy();e.container.cycle()},remove:function(t){var n=this.opts();var r,i,s=[],o=1;for(var u=0;u<n.slides.length;u++){r=n.slides[u];if(u==t){i=r}else{s.push(r);e(r).data("cycle.opts").slideNum=o;o++}}
if(i){n.slides=e(s);n.slideCount--;e(i).remove();if(t==n.currSlide)
n.API.advanceSlide(1);else if(t<n.currSlide)
n.currSlide--;else
n.currSlide++;n.API.trigger("cycle-slide-removed",[n,t,i]).log("cycle-slide-removed");n.API.updateView()}}});e(document).on("click.cycle","[data-cycle-cmd]",function(t){t.preventDefault();var n=e(this);var r=n.data("cycle-cmd");var i=n.data("cycle-context")||".cycle-slideshow";e(i).cycle(r,n.data("cycle-arg"))})})(e);(function(e){"use strict";function t(t,n){var r;if(t._hashFence){t._hashFence=false;return}
r=window.location.hash.substring(1);t.slides.each(function(i){if(e(this).data("cycle-hash")==r){if(n===true){t.startingSlide=i}else{var s=t.currSlide<i;t.nextSlide=i;t.API.prepareTx(true,s)}
return false}})}
e(document).on("cycle-pre-initialize",function(n,r){t(r,true);r._onHashChange=function(){t(r,false)};e(window).on("hashchange",r._onHashChange)});e(document).on("cycle-update-view",function(e,t,n){if(n.hash&&"#"+n.hash!=window.location.hash){t._hashFence=true;window.location.hash=n.hash}});e(document).on("cycle-destroyed",function(t,n){if(n._onHashChange){e(window).off("hashchange",n._onHashChange)}})})(e);(function(e){"use strict";e.extend(e.fn.cycle.defaults,{loader:false});e(document).on("cycle-bootstrap",function(t,n){function i(t,i){function a(t){var o;if(n.loader=="wait"){s.push(t);if(u===0){s.sort(f);r.apply(n.API,[s,i]);n.container.removeClass("cycle-loading")}}else{o=e(n.slides[n.currSlide]);r.apply(n.API,[t,i]);o.show();n.container.removeClass("cycle-loading")}}
function f(e,t){return e.data("index")-t.data("index")}
var s=[];if(e.type(t)=="string")
t=e.trim(t);else if(e.type(t)==="array"){for(var o=0;o<t.length;o++)
t[o]=e(t[o])[0]}
t=e(t);var u=t.length;if(!u)
return;t.css("visibility","hidden").appendTo("body").each(function(t){function c(){if(--o===0){--u;a(f)}}
var o=0;var f=e(this);var l=f.is("img")?f:f.find("img");f.data("index",t);l=l.filter(":not(.cycle-loader-ignore)").filter(':not([src=""])');if(!l.length){--u;s.push(f);return}
o=l.length;l.each(function(){if(this.complete){c()}else{e(this).load(function(){c()}).on("error",function(){if(--o===0){n.API.log("slide skipped; img not loaded:",this.src);if(--u===0&&n.loader=="wait"){r.apply(n.API,[s,i])}}})}})});if(u)
n.container.addClass("cycle-loading")}
var r;if(!n.loader)
return;r=n.API.add;n.API.add=i})})(e);(function(e){"use strict";function t(t,n,r){var i;var s=t.API.getComponent("pager");s.each(function(){var s=e(this);if(n.pagerTemplate){var o=t.API.tmpl(n.pagerTemplate,n,t,r[0]);i=e(o).appendTo(s)}else{i=s.children().eq(t.slideCount-1)}
i.on(t.pagerEvent,function(e){if(!t.pagerEventBubble)
e.preventDefault();t.API.page(s,e.currentTarget)})})}
function n(e,t){var n=this.opts();if(n.busy&&!n.manualTrump)
return;var r=e.children().index(t);var i=r;var s=n.currSlide<i;if(n.currSlide==i){return}
n.nextSlide=i;n._tempFx=n.pagerFx;n.API.prepareTx(true,s);n.API.trigger("cycle-pager-activated",[n,e,t])}
e.extend(e.fn.cycle.defaults,{pager:"> .cycle-pager",pagerActiveClass:"cycle-pager-active",pagerEvent:"click.cycle",pagerEventBubble:undefined,pagerTemplate:"<span>&bull;</span>"});e(document).on("cycle-bootstrap",function(e,n,r){r.buildPagerLink=t});e(document).on("cycle-slide-added",function(e,t,r,i){if(t.pager){t.API.buildPagerLink(t,r,i);t.API.page=n}});e(document).on("cycle-slide-removed",function(t,n,r,i){if(n.pager){var s=n.API.getComponent("pager");s.each(function(){var t=e(this);e(t.children()[r]).remove()})}});e(document).on("cycle-update-view",function(t,n,r){var i;if(n.pager){i=n.API.getComponent("pager");i.each(function(){e(this).children().removeClass(n.pagerActiveClass).eq(n.currSlide).addClass(n.pagerActiveClass)})}});e(document).on("cycle-destroyed",function(e,t){var n=t.API.getComponent("pager");if(n){n.children().off(t.pagerEvent);if(t.pagerTemplate)
n.empty()}})})(e);(function(e){"use strict";e.extend(e.fn.cycle.defaults,{next:"> .cycle-next",nextEvent:"click.cycle",disabledClass:"disabled",prev:"> .cycle-prev",prevEvent:"click.cycle",swipe:false});e(document).on("cycle-initialized",function(e,t){t.API.getComponent("next").on(t.nextEvent,function(e){e.preventDefault();t.API.next()});t.API.getComponent("prev").on(t.prevEvent,function(e){e.preventDefault();t.API.prev()});if(t.swipe){var n=t.swipeVert?"swipeUp.cycle":"swipeLeft.cycle swipeleft.cycle";var r=t.swipeVert?"swipeDown.cycle":"swipeRight.cycle swiperight.cycle";t.container.on(n,function(e){t._tempFx=t.swipeFx;t.API.next()});t.container.on(r,function(){t._tempFx=t.swipeFx;t.API.prev()})}});e(document).on("cycle-update-view",function(e,t,n,r){if(t.allowWrap)
return;var i=t.disabledClass;var s=t.API.getComponent("next");var o=t.API.getComponent("prev");var u=t._prevBoundry||0;var a=t._nextBoundry!==undefined?t._nextBoundry:t.slideCount-1;if(t.currSlide==a)
s.addClass(i).prop("disabled",true);else
s.removeClass(i).prop("disabled",false);if(t.currSlide===u)
o.addClass(i).prop("disabled",true);else
o.removeClass(i).prop("disabled",false)});e(document).on("cycle-destroyed",function(e,t){t.API.getComponent("prev").off(t.nextEvent);t.API.getComponent("next").off(t.prevEvent);t.container.off("swipeleft.cycle swiperight.cycle swipeLeft.cycle swipeRight.cycle swipeUp.cycle swipeDown.cycle")})})(e);(function(e){"use strict";e.extend(e.fn.cycle.defaults,{progressive:false});e(document).on("cycle-pre-initialize",function(t,n){if(!n.progressive)
return;var r=n.API;var i=r.next;var s=r.prev;var o=r.prepareTx;var u=e.type(n.progressive);var a,f;if(u=="array"){a=n.progressive}else if(e.isFunction(n.progressive)){a=n.progressive(n)}else if(u=="string"){f=e(n.progressive);a=e.trim(f.html());if(!a)
return;if(/^(\[)/.test(a)){try{a=e.parseJSON(a)}catch(l){r.log("error parsing progressive slides",l);return}}else{a=a.split(new RegExp(f.data("cycle-split")||"\n"));if(!a[a.length-1])
a.pop()}}
if(o){r.prepareTx=function(e,t){var r,i;if(e||a.length===0){o.apply(n.API,[e,t]);return}
if(t&&n.currSlide==n.slideCount-1){i=a[0];a=a.slice(1);n.container.one("cycle-slide-added",function(e,t){setTimeout(function(){t.API.advanceSlide(1)},50)});n.API.add(i)}else if(!t&&n.currSlide===0){r=a.length-1;i=a[r];a=a.slice(0,r);n.container.one("cycle-slide-added",function(e,t){setTimeout(function(){t.currSlide=1;t.API.advanceSlide(-1)},50)});n.API.add(i,true)}else{o.apply(n.API,[e,t])}}}
if(i){r.next=function(){var e=this.opts();if(a.length&&e.currSlide==e.slideCount-1){var t=a[0];a=a.slice(1);e.container.one("cycle-slide-added",function(e,t){i.apply(t.API);t.container.removeClass("cycle-loading")});e.container.addClass("cycle-loading");e.API.add(t)}else{i.apply(e.API)}}}
if(s){r.prev=function(){var e=this.opts();if(a.length&&e.currSlide===0){var t=a.length-1;var n=a[t];a=a.slice(0,t);e.container.one("cycle-slide-added",function(e,t){t.currSlide=1;t.API.advanceSlide(-1);t.container.removeClass("cycle-loading")});e.container.addClass("cycle-loading");e.API.add(n,true)}else{s.apply(e.API)}}}})})(e);(function(e){"use strict";e.extend(e.fn.cycle.defaults,{tmplRegex:"{{((.)?.*?)}}"});e.extend(e.fn.cycle.API,{tmpl:function(t,n){var r=new RegExp(n.tmplRegex||e.fn.cycle.defaults.tmplRegex,"g");var i=e.makeArray(arguments);i.shift();return t.replace(r,function(t,n){var r,s,o,u,a=n.split(".");for(r=0;r<i.length;r++){o=i[r];if(!o)
continue;if(a.length>1){u=o;for(s=0;s<a.length;s++){o=u;u=u[a[s]]||n}}else{u=o[n]}
if(e.isFunction(u))
return u.apply(o,i);if(u!==undefined&&u!==null&&u!=n)
return u}
return n})}})})(e);(function(e){"use strict";function n(){try{this.playVideo()}catch(e){}}
function r(){try{this.pauseVideo()}catch(e){}}
var t='<div class=cycle-youtube><object width="640" height="360">'+'<param name="movie" value="{{url}}"></param>'+'<param name="allowFullScreen" value="{{allowFullScreen}}"></param>'+'<param name="allowscriptaccess" value="always"></param>'+'<param name="wmode" value="opaque"></param>'+'<embed src="{{url}}" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="{{allowFullScreen}}" wmode="opaque"></embed>'+"</object></div>";e.extend(e.fn.cycle.defaults,{youtubeAllowFullScreen:true,youtubeAutostart:false,youtubeAutostop:true});e(document).on("cycle-bootstrap",function(i,s){if(!s.youtube)
return;s.hideNonActive=false;s.container.find(s.slides).each(function(n){if(e(this).attr("href")===undefined)
return;var r,i=e(this),o=i.attr("href");var u=s.youtubeAllowFullScreen?"true":"false";o+=(/\?/.test(o)?"&":"?")+"enablejsapi=1";if(s.youtubeAutostart&&s.startingSlide===n)
o+="&autoplay=1";r=s.API.tmpl(t,{url:o,allowFullScreen:u});i.replaceWith(r)});s.slides=s.slides.replace(/(\b>?a\b)/,"div.cycle-youtube");if(s.youtubeAutostart){s.container.on("cycle-initialized cycle-after",function(t,r){var i=t.type=="cycle-initialized"?r.currSlide:r.nextSlide;e(r.slides[i]).find("object,embed").each(n)})}
if(s.youtubeAutostop){s.container.on("cycle-before",function(t,n){e(n.slides[n.currSlide]).find("object,embed").each(r)})}})})(e);(function(e){"use strict";function s(n){return{preInit:function(e){e.slides.css(t)},transition:function(t,r,i,s,o){var u=t,a=e(r),f=e(i),l=u.speed/2;n.call(f,-90);f.css({display:"block",visibility:"visible","background-position":"-90px",opacity:1});a.css("background-position","0px");a.animate({backgroundPosition:90},{step:n,duration:l,easing:u.easeOut||u.easing,complete:function(){t.API.updateView(false,true);f.animate({backgroundPosition:0},{step:n,duration:l,easing:u.easeIn||u.easing,complete:o})}})}}}
function o(t){return function(n){var r=e(this);r.css({"-webkit-transform":"rotate"+t+"("+n+"deg)","-moz-transform":"rotate"+t+"("+n+"deg)","-ms-transform":"rotate"+t+"("+n+"deg)","-o-transform":"rotate"+t+"("+n+"deg)",transform:"rotate"+t+"("+n+"deg)"})}}
var t,n=document.createElement("div").style,r=e.fn.cycle.transitions,i=n.transform!==undefined||n.MozTransform!==undefined||n.webkitTransform!==undefined||n.oTransform!==undefined||n.msTransform!==undefined;if(i&&n.msTransform!==undefined){n.msTransform="rotateY(0deg)";if(!n.msTransform)
i=false}
if(i){r.flipHorz=s(o("Y"));r.flipVert=s(o("X"));t={"-webkit-backface-visibility":"hidden","-moz-backface-visibility":"hidden","-o-backface-visibility":"hidden","backface-visibility":"hidden"}}else{r.flipHorz=r.scrollHorz;r.flipVert=r.scrollVert||r.scrollHorz}})(e);(function(e){"use strict";e.fn.cycle.transitions.scrollVert={before:function(e,t,n,r){e.API.stackSlides(e,t,n,r);var i=e.container.css("overflow","hidden").height();e.cssBefore={top:r?-i:i,left:0,opacity:1,display:"block",visibility:"visible"};e.animIn={top:0};e.animOut={top:r?i:-i}}}})(e);(function(e){"use strict";e.fn.cycle.transitions.shuffle={transition:function(t,n,r,i,s){function c(e){this.stack(t,n,r,i);e()}
e(r).css({display:"block",visibility:"visible"});var o=t.container.css("overflow","visible").width();var u=t.speed/2;var a=i?n:r;t=t.API.getSlideOpts(i?t.currSlide:t.nextSlide);var f={left:-o,top:15};var l=t.slideCss||{left:0,top:0};if(t.shuffleLeft!==undefined){f.left=f.left+parseInt(t.shuffleLeft,10)||0}else if(t.shuffleRight!==undefined){f.left=o+parseInt(t.shuffleRight,10)||0}
if(t.shuffleTop){f.top=t.shuffleTop}
e(a).animate(f,u,t.easeIn||t.easing).queue("fx",e.proxy(c,this)).animate(l,u,t.easeOut||t.easing,s)},stack:function(t,n,r,i){var s,o;if(i){t.API.stackSlides(r,n,i);e(n).css("zIndex",1)}else{o=1;for(s=t.nextSlide-1;s>=0;s--){e(t.slides[s]).css("zIndex",o++)}
for(s=t.slideCount-1;s>t.nextSlide;s--){e(t.slides[s]).css("zIndex",o++)}
e(r).css("zIndex",t.maxZ);e(n).css("zIndex",t.maxZ-1)}}}})(e);(function(e){"use strict";e.fn.cycle.transitions.tileSlide=e.fn.cycle.transitions.tileBlind={before:function(t,n,r,i){t.API.stackSlides(n,r,i);e(n).css({display:"block",visibility:"visible"});t.container.css("overflow","hidden");t.tileDelay=t.tileDelay||t.fx=="tileSlide"?100:125;t.tileCount=t.tileCount||7;t.tileVertical=t.tileVertical!==false;if(!t.container.data("cycleTileInitialized")){t.container.on("cycle-destroyed",e.proxy(this.onDestroy,t.API));t.container.data("cycleTileInitialized",true)}},transition:function(t,n,r,i,s){function S(e){o.eq(e).animate(y,{duration:t.speed,easing:t.easing,complete:function(){if(i?d-1===e:0===e){t._tileAniCallback()}}});setTimeout(function(){if(i?d-1!==e:0!==e){S(i?e+1:e-1)}},t.tileDelay)}
t.slides.not(n).not(r).css("visibility","hidden");var o=e();var u=e(n),a=e(r);var f,l,c,h,p,d=t.tileCount,v=t.tileVertical,m=t.container.height(),g=t.container.width();if(v){l=Math.floor(g/d);h=g-l*(d-1);c=p=m}else{l=h=g;c=Math.floor(m/d);p=m-c*(d-1)}
t.container.find(".cycle-tiles-container").remove();var y;var b={left:0,top:0,overflow:"hidden",position:"absolute",margin:0,padding:0};if(v){y=t.fx=="tileSlide"?{top:m}:{width:0}}else{y=t.fx=="tileSlide"?{left:g}:{height:0}}
var w=e('<div class="cycle-tiles-container"></div>');w.css({zIndex:u.css("z-index"),overflow:"visible",position:"absolute",top:0,left:0,direction:"ltr"});w.insertBefore(r);for(var E=0;E<d;E++){f=e("<div></div>").css(b).css({width:d-1===E?h:l,height:d-1===E?p:c,marginLeft:v?E*l:0,marginTop:v?0:E*c}).append(u.clone().css({position:"relative",maxWidth:"none",width:u.width(),margin:0,padding:0,marginLeft:v?-(E*l):0,marginTop:v?0:-(E*c)}));o=o.add(f)}
w.append(o);u.css("visibility","hidden");a.css({opacity:1,display:"block",visibility:"visible"});S(i?0:d-1);t._tileAniCallback=function(){a.css({display:"block",visibility:"visible"});u.css("visibility","hidden");w.remove();s()}},stopTransition:function(e){e.container.find("*").stop(true,true);if(e._tileAniCallback)
e._tileAniCallback()},onDestroy:function(e){var t=this.opts();t.container.find(".cycle-tiles-container").remove()}}})(e);})(jQuery)